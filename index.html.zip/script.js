// Irritate Bubble — addictive hyper-casual with bomb bubbles, escalating difficulty, music + mute
(() => {
  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d');

  const hud = {
    score: document.getElementById('score'),
    best: document.getElementById('best'),
    startOverlay: document.getElementById('startOverlay'),
    startBtn: document.getElementById('startBtn'),
    gameOver: document.getElementById('gameOver'),
    againBtn: document.getElementById('againBtn'),
    taunt: document.getElementById('taunt'),
    finalScore: document.getElementById('finalScore'),
    muteBtn: document.getElementById('muteBtn'),
  };

  function resize(){
    const dpr = window.devicePixelRatio || 1;
    canvas.width = Math.floor(innerWidth * dpr);
    canvas.height = Math.floor(innerHeight * dpr);
    canvas.style.width = innerWidth + 'px';
    canvas.style.height = innerHeight + 'px';
    ctx.setTransform(dpr,0,0,dpr,0,0);
  }
  addEventListener('resize', resize); resize();

  const S = {
    running: false,
    score: 0,
    best: Number(localStorage.getItem('ib_best') || 0),
    bubbles: [],
    particles: [],
    spawnEvery: 900, // ms (auto tunes)
    lastSpawn: 0,
    musicOn: true
  };
  hud.best.textContent = S.best;

  // Audio (WebAudio)
  const audio = { ctx:null, sfxGain:null, loop:null };
  function initAudio(){
    if(audio.ctx) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    audio.ctx = new AC();
    const master = audio.ctx.createGain();
    const musicGain = audio.ctx.createGain();
    audio.sfxGain = audio.ctx.createGain();
    musicGain.gain.value = 0.08;
    audio.sfxGain.gain.value = 0.25;
    musicGain.connect(master);
    audio.sfxGain.connect(master);
    master.connect(audio.ctx.destination);

    // Tiny loop
    audio.loop = setInterval(()=>{
      if(!S.musicOn) return;
      tone(261.63, 0.14, 'sine', 0.14);
      setTimeout(()=> tone(329.63, 0.14, 'sine', 0.14), 210);
    }, 600);
  }
  function tone(freq, dur=0.12, type='sine', gain=0.18){
    if(!audio.ctx) return;
    const o = audio.ctx.createOscillator();
    const g = audio.ctx.createGain();
    o.type = type; o.frequency.value = freq;
    g.gain.value = gain; o.connect(g); g.connect(audio.sfxGain);
    const t = audio.ctx.currentTime;
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(gain, t+0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t+dur);
    o.start(); o.stop(t+dur+0.02);
  }
  function popSfx(){ tone(600+Math.random()*120,0.08,'triangle',0.42); }
  function boomSfx(){
    if(!audio.ctx) return;
    const n = audio.ctx.createBufferSource();
    const len = audio.ctx.sampleRate * 0.5;
    const buf = audio.ctx.createBuffer(1, len, audio.ctx.sampleRate);
    const data = buf.getChannelData(0);
    for(let i=0;i<len;i++){ data[i] = (Math.random()*2-1) * (1 - i/len); }
    n.buffer = buf;
    const g = audio.ctx.createGain(); g.gain.value = 0.9;
    n.connect(g); g.connect(audio.sfxGain); n.start();
  }

  hud.muteBtn.addEventListener('click', ()=>{
    S.musicOn = !S.musicOn;
    hud.muteBtn.textContent = S.musicOn ? '🔊' : '🔇';
  });
  hud.startBtn.addEventListener('click', ()=>{
    initAudio();
    hud.startOverlay.classList.remove('show');
    startGame();
  });
  hud.againBtn.addEventListener('click', ()=>{
    hud.gameOver.classList.remove('show');
    startGame();
  });

  class Bubble{
    constructor(score){
      this.r = rand(16, 34);
      this.x = rand(this.r, innerWidth - this.r);
      this.y = innerHeight + this.r + Math.random()*60;
      const base = Math.min(2.2, 0.9 + score*0.02);
      this.vy = -rand(base, base+1.4);
      this.vx = rand(-0.3,0.3);
      const bombChance = Math.min(0.25, 0.05 + score*0.003);
      this.bomb = Math.random() < bombChance;
      this.hue = this.bomb ? 0 : rand(180, 260);
      this.dead = false;
    }
    update(dt){
      this.x += this.vx * dt * 0.06;
      this.y += this.vy * dt * 0.06;
      if(this.y + this.r < -40) this.dead = true;
    }
    draw(){
      const g = ctx.createRadialGradient(
        this.x - this.r*0.4, this.y - this.r*0.6, this.r*0.1,
        this.x, this.y, this.r
      );
      if(this.bomb){
        g.addColorStop(0, `hsla(0, 100%, 75%, .95)`);
        g.addColorStop(0.5, `hsla(0, 90%, 55%, .6)`);
        g.addColorStop(1, `hsla(0, 90%, 40%, .3)`);
      }else{
        g.addColorStop(0, `hsla(${this.hue}, 90%, 95%, .9)`);
        g.addColorStop(0.45, `hsla(${this.hue}, 85%, 70%, .65)`);
        g.addColorStop(1, `hsla(${this.hue}, 90%, 45%, .35)`);
      }
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(this.x,this.y,this.r,0,Math.PI*2); ctx.fill();
      ctx.beginPath();
      ctx.ellipse(this.x - this.r*0.35, this.y - this.r*0.55, this.r*0.15, this.r*0.25, -0.5, 0, Math.PI*2);
      ctx.fillStyle = 'rgba(255,255,255,.55)'; ctx.fill();
      ctx.strokeStyle = this.bomb ? 'rgba(255,200,200,.45)' : 'rgba(255,255,255,.35)';
      ctx.lineWidth = 2; ctx.stroke();
    }
    contains(px,py){ const dx=px-this.x, dy=py-this.y; return dx*dx+dy*dy <= this.r*this.r; }
  }

  class Particle{
    constructor(x,y,hue){
      this.x=x; this.y=y; this.vx=rand(-2.2,2.2); this.vy=rand(-2.8,-0.8);
      this.life=rand(450,900); this.hue=hue; this.size=rand(2,5);
    }
    update(dt){ this.vy+=0.004*dt; this.x+=this.vx*dt*0.06; this.y+=this.vy*dt*0.06; this.life-=dt; }
    draw(){ ctx.fillStyle=`hsla(${this.hue},90%,70%,${Math.max(0,this.life/900)})`; ctx.beginPath(); ctx.arc(this.x,this.y,this.size,0,Math.PI*2); ctx.fill(); }
    get dead(){ return this.life<=0; }
  }

  function spawn(){
    const now = performance.now();
    if(now - S.lastSpawn > S.spawnEvery){
      S.lastSpawn = now;
      const n = Math.random() < 0.25 ? 2 : 1;
      for(let i=0;i<n;i++) S.bubbles.push(new Bubble(S.score));
    }
  }

  function updateSpawnRate(){
    const base = 900;
    S.spawnEvery = Math.max(280, base - S.score*14);
  }

  function startGame(){
    S.running = true;
    S.score = 0; hud.score.textContent = '0';
    S.bubbles = []; S.particles = [];
    S.lastSpawn = 0; updateSpawnRate();
    last = performance.now();
  }

  function gameOver(taunt="Oops!"){
    if(!S.running) return;
    S.running = false; boomSfx();
    if(S.score > S.best){ S.best = S.score; localStorage.setItem('ib_best', String(S.best)); hud.best.textContent = S.best; }
    hud.finalScore.textContent = S.score;
    hud.taunt.textContent = taunt;
    setTimeout(()=> hud.gameOver.classList.add('show'), 300);
  }

  function handlePointer(x,y){
    if(!S.running) return;
    for(let i=S.bubbles.length-1; i>=0; i--){
      const b = S.bubbles[i];
      if(b.contains(x,y)){
        if(b.bomb){
          gameOver(randomTaunt());
        }else{
          S.bubbles.splice(i,1);
          S.score += 1; hud.score.textContent = S.score;
          updateSpawnRate(); popSfx();
          for(let j=0;j<12;j++) S.particles.push(new Particle(b.x,b.y,b.hue));
        }
        break;
      }
    }
  }

  canvas.addEventListener('click', e => {
    const r = canvas.getBoundingClientRect();
    handlePointer(e.clientX - r.left, e.clientY - r.top);
  });
  canvas.addEventListener('touchstart', e => {
    const r = canvas.getBoundingClientRect();
    for(const t of e.changedTouches){
      handlePointer(t.clientX - r.left, t.clientY - r.top);
    }
  }, {passive:true});

  function randomTaunt(){
    const msgs = [
      "LOL 😅",
      "Nice try! 😂",
      "Boom! 💥",
      "Again? Again. 🤭",
      "Irritated yet? 😈",
      "One more? You know you want to. 😉"
    ];
    return msgs[Math.floor(Math.random()*msgs.length)];
  }

  const bokeh = Array.from({length: 26}, () => ({
    x: Math.random()*innerWidth,
    y: Math.random()*innerHeight,
    r: rand(20, 80),
    s: rand(0.2, 0.6),
    hue: rand(180, 260),
    a: rand(0.05, 0.14)
  }));

  function drawBackground(t){
    for (const bb of bokeh) {
      bb.y -= bb.s * 0.5;
      if (bb.y + bb.r < -10) { bb.y = innerHeight + bb.r + 10; bb.x = rand(0, innerWidth); }
      const g = ctx.createRadialGradient(bb.x - bb.r*0.4, bb.y - bb.r*0.4, 1, bb.x, bb.y, bb.r);
      g.addColorStop(0, `hsla(${bb.hue}, 100%, 60%, ${bb.a})`);
      g.addColorStop(1, `hsla(${bb.hue}, 80%, 40%, 0)`);
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(bb.x, bb.y, bb.r, 0, Math.PI*2); ctx.fill();
    }
  }

  let last = performance.now();
  function loop(t){
    requestAnimationFrame(loop);
    const dt = Math.min(50, t - last); last = t;
    ctx.clearRect(0,0,innerWidth,innerHeight);
    drawBackground(t);
    if(S.running){ spawn(); }
    for(let i=S.bubbles.length-1; i>=0; i--){
      const b = S.bubbles[i]; b.update(dt); b.draw(); if(b.dead) S.bubbles.splice(i,1);
    }
    for(let i=S.particles.length-1; i>=0; i--){
      const p = S.particles[i]; p.update(dt); p.draw(); if(p.dead) S.particles.splice(i,1);
    }
  }
  requestAnimationFrame(loop);

  function rand(a,b){ return a + Math.random()*(b-a); }

})();
